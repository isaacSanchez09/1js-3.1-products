'use strict'

const Category = require("../model/category.class");
const Product = require("../model/product.class");


class View{
    
    init(categories, products, callback1, callback2, callback3){
        this.initCategories(categories);
        this.initProducts(products, callback1, callback2, callback3);
    }

    renderCategory(category){
        const opcionesCategorias = document.getElementById('categorias');
        let nuevaOption = this.appendCategory(category);
        opcionesCategorias.appendChild(nuevaOption);
    }

    renderProduct(product, callback1, callback2, callback3){
        let productos = document.getElementById('listaProductos');
        let nuevoProducto = this.appendProduct(product);
        productos.appendChild(nuevoProducto);
        this.appendEvents(product, callback1, callback2, callback3);
    }

    deleteProduct(id){
        let productos = document.getElementById('listaProductos');
        productos.removeChild(document.getElementById(`producto${id}`))
    }

    renderMessaje(mensajeEror){
        let error = document.getElementById('messages');
        let div = document.createElement('div');
        div.classList = `alert alert-danger alert-dismissible`;
        div.setAttribute('role','alert');
        div.innerHTML +=`
        ${mensajeEror}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" onclick="this.parentElement.remove()"></button>
        </div>`;
        error.appendChild(div);

        setTimeout(function(){
            div.remove();
        },5000);
    }

    initCategories(categories){
        const opcionesCategorias = document.getElementById('categorias');
        categories.forEach(category =>{
            let newOption = this.appendCategory(category);
            opcionesCategorias.appendChild(newOption);
        })
    }

    deleteCategory(categories){
        const opcionesCategorias = document.getElementById('categorias');
        let option = document.getElementById(`category${categories.id}`);
        opcionesCategorias.removeChild(option);
    }

    
    setTotalImport(totalImport){
        let importe = document.getElementById('importeTotal');
        importe.textContent = totalImport.toFixed(2);
    }

    editForm(prod){
        document.getElementById('newprod-id').value = prod.id;
        document.getElementById('newprod-name').value = prod.name;
        document.getElementById('newprod-price').value = prod.price;
        document.getElementById('categorias').value = prod.category;
        document.getElementById('newprod-units').value = prod.units;
        document.getElementById('botonFormulario').textContent = "Editar";
        document.getElementById('action').value = "edit";
        document.getElementById('tituloForm').textContent = "Editar Producto";
    }

    editProduct(prod){
        let producto = document.getElementById(`producto${prod.id}`);
        let name = producto.firstChild.nextElementSibling.nextElementSibling;
        name.textContent = prod.name;
        let category = name.nextElementSibling;
        category.textContent = prod.category;
        let precio = category.nextElementSibling.nextElementSibling;
        precio.textContent = prod.price;
        this.renderUnits(prod);
        document.getElementById('action').value = "add";
        document.getElementById('botonFormulario').textContent = "Añadir";
        document.getElementById('tituloForm').textContent = "Añadir Producto";
    }

    initProducts(products, callback1, callback2, callback3){
        const listaProductos = document.getElementById('listaProductos')
        products.forEach(product =>{
            let nuevoProducto = this.appendProduct(product);
            listaProductos.appendChild(nuevoProducto);
            this.appendEvents(product, callback1, callback2, callback3);
        })
    }

    renderUnits(product){
        let units = document.getElementById(`units${product.id}`);
        let importe = document.getElementById(`import${product.id}`);
        units.textContent = product.units;
        importe.textContent = (product.productImport()).toFixed(2);
    }

    appendProduct(product){
        let nuevoProducto = document.createElement('tr');
            nuevoProducto.id = `producto${product.id}`
            nuevoProducto.innerHTML = `
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${product.category}</td>
            <td id="units${product.id}">${product.units}</td>
            <td id="price${product.id}">${product.price} €/u</td>
            <td id="import${product.id}">${product.productImport()}</td>
            <td>
                <button class="btn" id="subirUnidades${product.id}"><span class="material-icons">add</span></button>
                <button class="btn btn-danger" id="eliminarProducto${product.id}"><span class="material-icons">delete</span></button>
                <button class="btn btn-warning" id="editarProducto${product.id}"><span class="material-icons">edit</span></button>
                <button class="btn" id="bajarUnidades${product.id}"><span class="material-icons">remove</span></button>
            </td>`
            return nuevoProducto;
    }

    initMenu(){
        let addProduct = document.getElementById("addProd-View");
        addProduct.addEventListener('click', () =>{this.viewElement(addProduct)});
    }

    viewElement(element){
        let productList = document.getElementById('prodList');
        element.addEventListener('click', addProduct.classList.remove('oculto'));
    }

    appendCategory(category){
        let nuevaOption = document.createElement('option');
        nuevaOption.id = "category" + category.id;
        nuevaOption.value = category.id
        nuevaOption.label = category.name;
        return nuevaOption;
    }

    appendEvents(product, callback1, callback2, callback3){
        document.getElementById(`eliminarProducto${product.id}`).addEventListener('click', () => {
            callback1(product.id);
        })
        document.getElementById(`subirUnidades${product.id}`).addEventListener('click', () => {
            callback2(product.id);
        })
        document.getElementById(`bajarUnidades${product.id}`).addEventListener('click', () => {
            callback3(product.id);
        })
        document.getElementById(`editarProducto${product.id}`).addEventListener('click', () => {
            this.editForm(product);
        })
    }
}

module.exports = View
